public enum Material {
  SEDA,
  JEAN,
  LANA,
  ALGODON,
  CUERO,
  GAMUZA,
  ACETATO,
  PLASTICO,
  FRIZA
}