public enum Trama {
  LISA,
  RAYADA,
  CON_LUNARES,
  A_CUADROS,
  UN_ESTAMPADO
}